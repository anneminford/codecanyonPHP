<?php
initiate_html_columns();

?>

<h3>Privacy Policy</h3>

<p><strong>Lorem ipsum</strong> dolor sit amet, consectetur adipiscing elit. Vivamus eleifend nibh urna, nec feugiat diam ultricies vel. Fusce vel faucibus orci.</p>

<p><strong>Lorem ipsum</strong> Suspendisse pulvinar tristique velit lobortis malesuada. Maecenas quis quam viverra, sollicitudin nisi in, tempor tellus. Donec ac dolor sed justo facilisis dapibus. </p>

<p><strong>Lorem ipsum</strong> estibulum fermentum nulla ac ipsum suscipit vehicula. Sed luctus sem et urna commodo varius. Mauris vel orci non metus gravida sodales.</p>

<p><strong>Lorem ipsum</strong> Ut hendrerit sapien ac ligula aliquet, vel aliquet nulla facilisis. Phasellus convallis lacus augue, a ultrices justo ultrices sit amet. Etiam pulvinar diam ut lectus consectetur euismod.</p>
