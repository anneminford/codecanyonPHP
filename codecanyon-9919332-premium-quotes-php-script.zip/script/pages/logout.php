<?php

User::logout();

?>