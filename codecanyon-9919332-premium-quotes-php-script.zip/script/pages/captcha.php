<?php
include '../core/classes/Captcha.php';

$captcha = new Captcha;

$captcha->process();
?>