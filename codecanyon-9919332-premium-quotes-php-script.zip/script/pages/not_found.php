<?php
initiate_html_columns();
echo $language->global->error_message->page_not_found;
?>