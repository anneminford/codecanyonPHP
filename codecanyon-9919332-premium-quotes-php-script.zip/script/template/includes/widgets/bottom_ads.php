<?php if(!empty($settings->bottom_ads)) { ?>
<div class="panel panel-default">
	<div class="panel-body center">
		<?php echo $settings->bottom_ads; ?>
	</div>
</div>
<?php } ?>