<?php if(!empty($settings->top_ads)) { ?>
<div class="panel panel-default">
	<div class="panel-body center">
		<?php echo $settings->top_ads; ?>
	</div>
</div>
<?php } ?>