	<?php if(isset($_GET['page']) && (!in_array($_GET['page'], $no_panel_pages))) { ?>
		</div><!-- END Panel Content -->
	</div><!-- END Main Panel -->
	<?php } ?>
</div><!-- END Main Column -->