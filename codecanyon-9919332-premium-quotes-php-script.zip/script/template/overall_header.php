<!DOCTYPE html>
<html>
	<?php include 'includes/head.php'; ?>
	<body>
		<?php include 'includes/menu.php'; ?>

		<?php include 'includes/presentation.php'; ?>
		
		<div class="container"><!-- Start Container -->

			<?php display_notifications(); ?>

			<?php include 'includes/widgets/top_ads.php'; ?>
