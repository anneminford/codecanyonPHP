<?php
$database->close();
ob_flush();
?>